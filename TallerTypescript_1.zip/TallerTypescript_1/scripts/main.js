import { series } from './data.js';
var seriesTbody = document.getElementById('series');
renderSeriesInTable(series);
function renderSeriesInTable(series) {
    console.log('Desplegando series');
    var avgSeasons = 0;
    var sumSeasons = 0;
    var numSeries = 0;
    series.forEach(function (serie) {
        var trElement = document.createElement("tr");
        trElement.innerHTML = "<td class=\"table-active\"><b>".concat(serie.id, "</b></td>\n                             <td class=\"table-active\"><p class= tituloSerie>").concat(serie.name, "</p></td>\n                             <td class=\"table-active\">").concat(serie.channel, "</td>\n                             <td class=\"table-active\">").concat(serie.seasons, "</td>");
        numSeries = numSeries + 1;
        sumSeasons = sumSeasons + serie.seasons;
        seriesTbody.appendChild(trElement);
    });
    avgSeasons = sumSeasons / numSeries;
    var trElement1 = document.createElement("tr");
    trElement1.innerHTML = "<p> Seasons average ".concat(avgSeasons, "</p>");
    seriesTbody.appendChild(trElement1);
}
/*function calculateAvgSeasons(series: Serie[]): void {
    console.log('Desplegando promedio de temporadas');
    let avgSeasons: number = 0;
    let sumSeasons: number = 0;
    let numSeries: number = 0;
    series.forEach((serie) =>{
        numSeries = numSeries + 1;
        sumSeasons = sumSeasons + serie.seasons;
    })
    avgSeasons = sumSeasons / numSeries;
    let trElement = document.createElement("tr");
    trElement.innerHTML = `<td>${avgSeasons}</td>`;
    seriesTbody.appendChild(trElement);
}*/ 
