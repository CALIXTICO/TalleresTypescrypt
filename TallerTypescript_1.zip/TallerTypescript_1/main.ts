import { Serie } from './serie.js';
import { series } from './data.js';

let seriesTbody: HTMLElement = document.getElementById('series')!;

renderSeriesInTable(series);

function renderSeriesInTable(series: Serie[]): void {
    console.log('Desplegando series');

    let avgSeasons: number = 0;
    let sumSeasons: number = 0;
    let numSeries: number = 0;

    series.forEach((serie) => {
      let trElement = document.createElement("tr");
      trElement.innerHTML = `<td class="table-active"><b>${serie.id}</b></td>
                             <td class="table-active"><p class= tituloSerie>${serie.name}</p></td>
                             <td class="table-active">${serie.channel}</td>
                             <td class="table-active">${serie.seasons}</td>`;

        numSeries = numSeries + 1;
        sumSeasons = sumSeasons + serie.seasons;
      seriesTbody.appendChild(trElement);
    });

    avgSeasons = sumSeasons / numSeries;
    let trElement1 = document.createElement("tr");
    trElement1.innerHTML = `<p> Seasons average ${avgSeasons}</p>`;
    seriesTbody.appendChild(trElement1);
}


/*function calculateAvgSeasons(series: Serie[]): void {
    console.log('Desplegando promedio de temporadas');
    let avgSeasons: number = 0;
    let sumSeasons: number = 0;
    let numSeries: number = 0;
    series.forEach((serie) =>{
        numSeries = numSeries + 1;
        sumSeasons = sumSeasons + serie.seasons;
    })
    avgSeasons = sumSeasons / numSeries;
    let trElement = document.createElement("tr");
    trElement.innerHTML = `<td>${avgSeasons}</td>`;
    seriesTbody.appendChild(trElement);
}*/