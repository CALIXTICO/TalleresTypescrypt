var Serie = /** @class */ (function () {
    function Serie(id, name, channel, seasons, info, link, image) {
        this.id = id;
        this.name = name;
        this.channel = channel;
        this.seasons = seasons;
        this.info = info;
        this.link = link;
        this.image = image;
    }
    return Serie;
}());
export { Serie };
