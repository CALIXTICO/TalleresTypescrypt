import { series } from './data.js';
var seriesTbody = document.getElementById('series');
var seriesImage = document.getElementById("seriesImage");
var infoTitulo = document.getElementById("infoTitulo");
var infoSerie = document.getElementById("infoSerie");
var linkSerie = document.getElementById("linkSerie");
renderSeriesInTable(series);
var btnsSeries = document.getElementsByClassName("tituloSerie");
var _loop_1 = function () {
    var btnSerie = btnsSeries[i];
    var clkSerie;
    btnSerie.addEventListener("click", function () {
        series.forEach(function (serie) {
            if (serie.name == btnSerie.textContent) {
                clkSerie = serie;
            }
        });
        seriesImage.src = clkSerie.image;
        infoTitulo.textContent = clkSerie.name;
        infoSerie.textContent = clkSerie.info;
        linkSerie.textContent = clkSerie.link;
        linkSerie.href = clkSerie.link;
    });
};
for (var i = 0, len = btnsSeries.length; i < len; i++) {
    _loop_1();
}
function renderSeriesInTable(series) {
    console.log('Desplegando series');
    var avgSeasons = 0;
    var sumSeasons = 0;
    var numSeries = 0;
    series.forEach(function (serie) {
        var trElement = document.createElement("tr");
        trElement.innerHTML = "<td class=\"table-active\"><b>".concat(serie.id, "</b></td>\n                             <td class=\"table-active\"><button class= \"tituloSerie\">").concat(serie.name, "</p></td>\n                             <td class=\"table-active\">").concat(serie.channel, "</td>\n                             <td class=\"table-active\">").concat(serie.seasons, "</td>");
        numSeries = numSeries + 1;
        sumSeasons = sumSeasons + serie.seasons;
        seriesTbody.appendChild(trElement);
    });
    avgSeasons = sumSeasons / numSeries;
    var trElement1 = document.createElement("tr");
    trElement1.innerHTML = "<p> Seasons average ".concat(avgSeasons, "</p>");
    seriesTbody.appendChild(trElement1);
}
function showSeriesInformation() {
    console.log('prueba');
}
