import { Serie } from './serie.js';
import { series } from './data.js';

var seriesTbody: HTMLElement = document.getElementById('series')!;
var seriesImage = document.getElementById("seriesImage") as HTMLImageElement;
var infoTitulo = document.getElementById("infoTitulo") as HTMLTitleElement;
var infoSerie = document.getElementById("infoSerie") as HTMLParagraphElement;
var linkSerie = document.getElementById("linkSerie") as HTMLAnchorElement;

renderSeriesInTable(series);

var btnsSeries = document.getElementsByClassName("tituloSerie")

for (var i = 0, len = btnsSeries.length; i < len; i++) {

    let btnSerie = btnsSeries[i];
    let clkSerie: Serie;

    btnSerie.addEventListener("click", function (){
        
        series.forEach((serie) => {
            if (serie.name == btnSerie.textContent) {clkSerie = serie}
        })

        seriesImage.src =  clkSerie.image;
        infoTitulo.textContent = clkSerie.name;
        infoSerie.textContent = clkSerie.info;
        linkSerie.textContent = clkSerie.link;
        linkSerie.href = clkSerie.link;
    });
}

function renderSeriesInTable(series: Serie[]): void {
    console.log('Desplegando series');

    let avgSeasons: number = 0;
    let sumSeasons: number = 0;
    let numSeries: number = 0;

    series.forEach((serie) => {
      let trElement = document.createElement("tr");
      trElement.innerHTML = `<td class="table-active"><b>${serie.id}</b></td>
                             <td class="table-active"><button class= "tituloSerie">${serie.name}</p></td>
                             <td class="table-active">${serie.channel}</td>
                             <td class="table-active">${serie.seasons}</td>`;

        numSeries = numSeries + 1;
        sumSeasons = sumSeasons + serie.seasons;
      seriesTbody.appendChild(trElement);
    });

    avgSeasons = sumSeasons / numSeries;
    let trElement1 = document.createElement("tr");
    trElement1.innerHTML = `<p> Seasons average ${avgSeasons}</p>`;
    seriesTbody.appendChild(trElement1);
}

function showSeriesInformation(){

    console.log('prueba');

}
